1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/04xij5nlcoj4_.js","/_next/static/chunks/06wnotvpy-wxf.js","/_next/static/chunks/0v_5i272w0~ak.js","/_next/static/chunks/0l3.c_p1ulri~.js","/_next/static/chunks/0h0d3wrjl9f3q.js","/_next/static/chunks/09ht5wvffgz_0.js","/_next/static/chunks/0t-1l4jpmwdjs.js"],"default"]
3:I[37457,["/_next/static/chunks/04xij5nlcoj4_.js","/_next/static/chunks/06wnotvpy-wxf.js","/_next/static/chunks/0v_5i272w0~ak.js","/_next/static/chunks/0l3.c_p1ulri~.js","/_next/static/chunks/0h0d3wrjl9f3q.js","/_next/static/chunks/09ht5wvffgz_0.js","/_next/static/chunks/0t-1l4jpmwdjs.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"iOa0CMaHSgW39MOoD8A19"}
